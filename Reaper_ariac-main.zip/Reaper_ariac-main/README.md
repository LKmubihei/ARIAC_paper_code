# Reaper_ariac   独立开发
## 1. 介绍
Reaper_ariac 是一个基于ROS2的机械臂抓取系统，用于解决Ariac竞赛中的任务。该系统包括机械臂、传感器、相机和控制系统等部分，通过ROS2实现与机械臂的通信和任务调度。https://github.com/usnistgov/ariac

## 2. 系统架构
运行下面命令启动环境

ros2 launch ariac_gazebo ariac.launch.py

[命令详细介绍](https://pages.nist.gov/ARIAC_docs/en/latest/getting_started/installation.html)，除了命令行传入参数，可以在launch文件中修改任务参数，参数文件在 

src/ARIAC-ariac2024/ariac_gazebo/config。

## 3. 系统运行
运行下面命令启动比赛运行程序

ros2 run competition_tutorials test.py

代码主体在 test.py 中，在运行 interface.start_competition() 比赛开始后，订阅的话题（传感器等）开始接受消息。

        self.left_basic_logical_off=True
        self.right_basic_logical_off=True
        self.right_bins_RGB_camera_off=True
        self.left_bins_RGB_camera_off=True

四个传感器，一个位置同时放置一个RGB和一个逻辑相机，RGB识别类型和颜色，逻辑相机识别位置。
目前采用的方案，由于识别消耗资源，在识别后关闭相机。 在match_parts函数中对两个相机的图像进行融合。

传送带上物体  修改kitting.yaml，修改后需要在 ariac_ws/目录下使用 colcon build

在  src/Reaper_ariac-main/competition_tutorials/config/sensors.yaml 文件中修改传感器信息

查看传感器信息 (https://pages.nist.gov/ARIAC_docs/en/latest/competition/sensors.html)

ros2 topic list   

查看话题类型

ros2 topic echo /ariac/sensors/left_basic_logical_camera/image


需要启动比赛才能看到消息

