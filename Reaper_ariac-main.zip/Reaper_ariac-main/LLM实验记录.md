# 1. 收集环境中零件信息
eg. blue_sensor flip on bin2

现在有环境中有零件['purple pump on bin2', 'blue battery on bin6']


# 2. 先不管机器人状态，在能正常工作时候调用LLM


# 3.对任务进行自然语言描述
有三种类型任务，
kitting 任务,需要将零件blue_sensor放置到agv2上，描述为： 'kitting blue_sensor on agv2'
assembly 任务，需要将零件purple_pump在上2号station上装配 描述为： assembly purple_pump on as2
combined 任务，需要将零件purple_pump在上2号station上装配 描述为： combined purple_pump on as2

下面是对于任务的具体实现描述：
Kitting Task
Kitting is the process of gathering parts into a ‘kit’. For a kitting task, the CCS is expected to:

Locate a tray with the proper tray id, on one of the two kit tray stations.

Pick, place, and lock the tray onto the specified AGVs.

Note

After placement, the tray should be locked to the AGV using the service /ariac/agv{n}_lock_tray to prevent the tray from shifting during transport.

Place the requested parts onto that kit tray in the specified quadrant.

Perform a quality check using the ROS service to check for faulty parts and fix any issues with the shipment.

Direct the AGV to the warehouse.

Submit the order

Assembly is the process of installing parts to a fixed insert. The CCS can assemble the parts in any order. For a trial where assembly tasks are required, the ARIAC environment starts with parts already located on AGVs. The CCS is expected to:

Lock the AGV trays.

Move the AGVs to the correct assembly station.

Call the pre-assembly poses service to get exact locations for the parts.

Use the ceiling robot to pick parts from the AGV and install each part into the insert.

Submit the assembly order.

Combined Task
A combined task is a task which requires both kitting and assembly. For a combined task, the CCS is expected to first perform a kitting task followed with an assembly task.

Note

The kitting task information is left to the competitors to figure out based on the assembly task information. The CCS can place parts anywhere on AGVs and then move those AGVs to the station where assembly is to be performed. Once the assembly is complete, the CCS can submit the assembly via a ROS service call (see Table 1). The AM will then evaluate the submitted assembly for scoring (kitting task is not scored).


现在有环境中有任务['kitting blue battery on agv4', 'kitting purple pump on agv4','assembly purple_pump on as2']


# 4. 先用最简单的方法实现，就是直接LLM输出两个命令

现在需要将任务分给两个机器人做，分配规则是  

Based on the provided task information, determine the optimal task assignment that minimizes total completion time.
Each task has an associated time for each robot to complete it. The plan should assign tasks to the Floor and Ceiling robots in a way that the total time to complete all tasks is minimized.
Floor robot can only handle kitting task,
The Ceiling robot can handle one task and has the following priority order: Combined > Assembly > Kitting.
if the part in flip ,it will spend more time to pick it up.

# 5. 任务分好了，现在需要把任务转换成命令,直接LLM输出两个命令

我想使用LLM解决对两个机器人的任务分配的问题
首先为了将环境信息和任务信息传入LLM，我写了两个函数做了一个自然语言抽象，将复杂的类信息压缩成关键信息

def gather_part_info(self):
    # Collect all parts into a list
    all_parts_on_bins = self.bin1_parts + self.bin4_parts + self.bin2_parts + self.bin3_parts + \
                        self.bin6_parts + self.bin7_parts + self.bin5_parts + self.bin8_parts

    part_descriptions = []

    for part in all_parts_on_bins:
        # Split the type and remove 'assembly' if present
        type_parts = part.type.split('_')
        if 'assembly' in type_parts:
            type_parts.remove('assembly')
        # Rearrange to put color first
        if len(type_parts) >= 2:
            color = type_parts[-1]
            type_name = '_'.join(type_parts[:-1])
            adjusted_type = f"{color}_{type_name}"
        else:
            adjusted_type = '_'.join(type_parts)
        # Replace underscores with spaces
        adjusted_type = adjusted_type.replace('_', ' ')
        # Determine if 'flip' is needed
        flip_str = 'flip' if part.need_flip else ''
        # Get the location
        location = part.location
        # Construct the description
        description = f"{adjusted_type} {flip_str} on {location}".strip()
        # Add to the list if not already present
        if description not in part_descriptions:
            part_descriptions.append(description)

    return part_descriptions

def gather_task_info(self):
    task_descriptions = []

    # Function to adjust product_type format
    def adjust_product_type(product_type):
        type_parts = product_type.split('_')
        if 'assembly' in type_parts:
            type_parts.remove('assembly')
        if len(type_parts) >= 2:
            color = type_parts[-1]
            type_name = '_'.join(type_parts[:-1])
            adjusted_type = f"{color}_{type_name}"
        else:
            adjusted_type = '_'.join(type_parts)
        return adjusted_type.replace('_', ' ')

    # Process kitting tasks
    for task in self.kitting_deque:
        adjusted_type = adjust_product_type(task.product_type)
        description = f"kitting {adjusted_type} on agv{task.agv_number}"
        task_descriptions.append(description)

    # Process assembly tasks
    for task in self.assembly_deque:
        adjusted_type = adjust_product_type(task.product_type)
        description = f"assembly {adjusted_type} on as{task.station}"
        task_descriptions.append(description)

    # Process combined tasks
    for task in self.combined_deque:
        adjusted_type = adjust_product_type(task.product_type)
        description = f"combined {adjusted_type} on as{task.station}"
        task_descriptions.append(description)

    return task_descriptions

最后得到
task_descriptions = [
    'kitting blue battery on agv4_1',
    'kitting blue battery on agv4_2',
    'kitting purple pump on agv4_3',
    'kitting purple pump on agv4_4',
    'assembly purple pump on as2'
    'assembly purple pump on as1'
]

part_descriptions = [
    'purple pump on bin2',
    'blue battery on bin6'
]

经过LLM规划，得到一个任务规划的JSON文件，其中包含以下内容：
{'floor_tasks': ['kitting blue battery on agv4_1',
  'kitting blue battery on agv4_2',
  'kitting purple pump on agv4_3'],
 'ceiling_tasks': ['assembly purple pump on as2',
  'kitting purple pump on agv4_4']}

现在我需要从JSON文件 中提取任务，生成对应的命令,我已经有一个函数可以实现这个功能
floor_cmd = self.create_floor_command(task,"kitting",min_part)  

但是这个命令中需要传入的参数有task,part，其中task是原始的任务类，part是零件类

现在的问题就是 怎么将从自然语言（'kitting blue battery on agv4_1'）中获得原来的 两个类变量task,part，从而能调用self.create_floor_command（我的想法是做字典映射，但是不知道怎么映射，希望你给出实现代码）  







