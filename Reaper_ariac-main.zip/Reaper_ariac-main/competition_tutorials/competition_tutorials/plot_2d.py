# bin_position = {
#     'bin1': [-1.9, 3.375, 0.72],
#     'bin2': [-1.9, 2.625, 0.72],
#     'bin3': [-2.65, 2.625, 0.72],
#     'bin4': [-2.65, 3.375, 0.72],
#     'bin5': [-1.9, -3.375, 0.72],
#     'bin6': [-1.9, -2.625, 0.72],
#     'bin7': [-2.65, -2.625, 0.72],
#     'bin8': [-2.65, -3.375, 0.72], 
# }
# agvs = {
#     'agv1': [-2.070051,4.799979, 0.0],
#     'agv2': [-2.070051,1.199981, 0.0],
#     'agv3': [-2.070051,-1.199981, 0.0],
#     'agv4': [-2.070051,-4.799979, 0.0],
# }


# 每个箱子是有9个格子的，箱子长宽分别为0.6，0.6
# 每个AGV是有4个格子的，长宽分别为0.52，0.38

# 画一张2D 图，用大方框表示每个箱子，用小方块表示每个格子，
# 用大方框表示每个AGV，用小方块表示每个格子，

# 还有两个机器人，用红点表是ceiling机器人，用蓝点表是floor机器人
# 其中ceiling的位置是  [-2.3,1.0,0.92]
# 其中floor的位置是  [-1.3,0.0,0.92]


# tray_slots_location={
#     "slot1": [-0.87,-5.84,0.735],
#     "slot2": [-1.30,-5.84,0.735],
#     "slot3": [-1.73,-5.84,0.735],
#     "slot4": [-1.73,5.84,0.735],
#     "slot5": [-1.30,5.84,0.735],
#     "slot6": [-0.87,5.84,0.735]
# }
# 有六个托盘,长宽分别为0.52，0.38,画6个方框，在对应方框上标记方框对应的键
# 在bin8上每一个格子也标记一个数显示其编号，在AGV4上每一个格子也标记一个数显示其编号

import matplotlib.pyplot as plt

# Define the positions of bins and AGVs
bin_position = {
    'bin1': [-1.9, 3.375, 0.72],
    'bin2': [-1.9, 2.625, 0.72],
    'bin3': [-2.65, 2.625, 0.72],
    'bin4': [-2.65, 3.375, 0.72],
    'bin5': [-1.9, -3.375, 0.72],
    'bin6': [-1.9, -2.625, 0.72],
    'bin7': [-2.65, -2.625, 0.72],
    'bin8': [-2.65, -3.375, 0.72]
}

agvs = {
    'agv1': [-2.070051,4.799979, 0.0],
    'agv2': [-2.070051,1.199981, 0.0],
    'agv3': [-2.070051,-1.199981, 0.0],
    'agv4': [-2.070051,-4.799979, 0.0]
}
# Tray slot configuration
tray_slots_location = {
    "slot1": [-0.87, -5.84, 0.735],
    "slot2": [-1.30, -5.84, 0.735],
    "slot3": [-1.73, -5.84, 0.735],
    "slot4": [-1.73, 5.84, 0.735],
    "slot5": [-1.30, 5.84, 0.735],
    "slot6": [-0.87, 5.84, 0.735]
}
bin_slot_positions={
'bin1_1': [-2.08, 3.195, 0.72],'bin1_2': [-2.08, 3.375, 0.72], 'bin1_3': [-2.08, 3.555, 0.72], 'bin1_4': [-1.9, 3.195, 0.72], 'bin1_5': [-1.9, 3.375, 0.72], 'bin1_6': [-1.9, 3.555, 0.72], 'bin1_7': [-1.72, 3.195, 0.72], 'bin1_8': [-1.72, 3.375, 0.72], 'bin1_9': [-1.72, 3.555, 0.72], 
 'bin2_1': [-2.08, 2.445, 0.72], 'bin2_2': [-2.08, 2.625, 0.72], 'bin2_3': [-2.08, 2.805, 0.72], 'bin2_4': [-1.9, 2.445, 0.72], 'bin2_5': [-1.9, 2.625, 0.72], 'bin2_6': [-1.9, 2.805, 0.72], 'bin2_7': [-1.72, 2.445, 0.72], 'bin2_8': [-1.72, 2.625, 0.72], 'bin2_9': [-1.72, 2.805, 0.72], 
 'bin3_1': [-2.83, 2.445, 0.72], 'bin3_2': [-2.83, 2.625, 0.72], 'bin3_3': [-2.83, 2.805, 0.72], 'bin3_4': [-2.65, 2.445, 0.72], 'bin3_5': [-2.65, 2.625, 0.72], 'bin3_6': [-2.65, 2.805, 0.72], 'bin3_7': [-2.4699999999999998, 2.445, 0.72], 'bin3_8': [-2.4699999999999998, 2.625, 0.72], 'bin3_9': [-2.4699999999999998, 2.805, 0.72],
'bin4_1': [-2.83, 3.195, 0.72], 'bin4_2': [-2.83, 3.375, 0.72], 'bin4_3': [-2.83, 3.555, 0.72], 'bin4_4': [-2.65, 3.195, 0.72], 'bin4_5': [-2.65, 3.375, 0.72], 'bin4_6': [-2.65, 3.555, 0.72], 'bin4_7': [-2.4699999999999998, 3.195, 0.72], 'bin4_8': [-2.4699999999999998, 3.375, 0.72], 'bin4_9': [-2.4699999999999998, 3.555, 0.72], 
'bin5_1': [-2.08, -3.555, 0.72], 'bin5_2': [-2.08, -3.375, 0.72], 'bin5_3': [-2.08, -3.195, 0.72], 'bin5_4': [-1.9, -3.555, 0.72], 'bin5_5': [-1.9, -3.375, 0.72], 'bin5_6': [-1.9, -3.195, 0.72], 'bin5_7': [-1.72, -3.555, 0.72], 'bin5_8': [-1.72, -3.375, 0.72], 'bin5_9': [-1.72, -3.195, 0.72], 
'bin6_1': [-2.08, -2.805, 0.72], 'bin6_2': [-2.08, -2.625, 0.72], 'bin6_3': [-2.08, -2.445, 0.72], 'bin6_4': [-1.9, -2.805, 0.72], 'bin6_5': [-1.9, -2.625, 0.72], 'bin6_6': [-1.9, -2.445, 0.72], 'bin6_7': [-1.72, -2.805, 0.72], 'bin6_8': [-1.72, -2.625, 0.72], 'bin6_9': [-1.72, -2.445, 0.72], 
'bin7_1': [-2.83, -2.805, 0.72], 'bin7_2': [-2.83, -2.625, 0.72], 'bin7_3': [-2.83, -2.445, 0.72], 'bin7_4': [-2.65, -2.805, 0.72], 'bin7_5': [-2.65, -2.625, 0.72], 'bin7_6': [-2.65, -2.445, 0.72], 'bin7_7': [-2.4699999999999998, -2.805, 0.72], 'bin7_8': [-2.4699999999999998, -2.625, 0.72], 'bin7_9': [-2.4699999999999998, -2.445, 0.72], 
'bin8_1': [-2.83, -3.555, 0.72], 'bin8_2': [-2.83, -3.375, 0.72], 'bin8_3': [-2.83, -3.195, 0.72], 'bin8_4': [-2.65, -3.555, 0.72], 'bin8_5': [-2.65, -3.375, 0.72], 'bin8_6': [-2.65, -3.195, 0.72], 'bin8_7': [-2.4699999999999998, -3.555, 0.72], 'bin8_8': [-2.4699999999999998, -3.375, 0.72], 'bin8_9': [-2.4699999999999998, -3.195, 0.72]
}
agv_slot_positions={'agv1_1': [-1.940051, 4.889979, 0.72], 'agv1_2': [-1.940051, 4.709979000000001, 0.72], 'agv1_3': [-2.2000509999999998, 4.889979, 0.72], 'agv1_4': [-2.2000509999999998, 4.709979000000001, 0.72], 'agv2_1': [-1.940051, 1.289981, 0.72], 'agv2_2': [-1.940051, 1.1099809999999999, 0.72], 'agv2_3': [-2.2000509999999998, 1.289981, 0.72], 'agv2_4': [-2.2000509999999998, 1.1099809999999999, 0.72], 'agv3_1': [-1.940051, -1.1099809999999999, 0.72], 'agv3_2': [-1.940051, -1.289981, 0.72], 'agv3_3': [-2.2000509999999998, -1.1099809999999999, 0.72], 'agv3_4': [-2.2000509999999998, -1.289981, 0.72], 'agv4_1': [-1.940051, -4.709979000000001, 0.72], 'agv4_2': [-1.940051, -4.889979, 0.72], 'agv4_3': [-2.2000509999999998, -4.709979000000001, 0.72], 'agv4_4': [-2.2000509999999998, -4.889979, 0.72]}

slot_reference_position = {
    1: [-0.18, -0.18, 0.0],
    2: [-0.18, -0.00, 0.0],
    3: [ 0.18, 0.18, 0.0],

    4: [-0.0, -0.18, 0.0],
    5: [-0.0, -0.00, 0.0],
    6: [ 0.0, 0.18, 0.0],

    7: [0.18, -0.18, 0.0],
    8: [0.0, -0.00, 0.0],
    9: [ 0.18, 0.18, 0.0],
}



# Calculate relative position of each quadrant cell for AGVs
agv_cell_relative_position =  {
    1: [0.13, 0.09],
    2: [0.13, -0.09],
    3: [-0.13, 0.09],
    4: [-0.13, -0.09]
}
# Define robots' positions
ceiling_robot = [-2.3, 1.0, 0.92]
floor_robot = [-1.3, 0.0, 0.92]

# Plot configuration
fig, ax = plt.subplots(figsize=(10, 10))

# Bin configuration
bin_size = (0.6, 0.6)
bin_grid = (3, 3)  # Each bin has a 3x3 grid

# AGV configuration
agv_size = (0.52, 0.38)
agv_grid = (2, 2)  # Each AGV has a 2x2 grid


for bin_name, pos in bin_position.items():
    bin_x, bin_y = pos[0], pos[1]
    rect = plt.Rectangle((bin_x - bin_size[0] / 2, bin_y - bin_size[1] / 2),
                         bin_size[0], bin_size[1], linewidth=2, edgecolor='black', facecolor='none')
    ax.add_patch(rect)
    
    # Draw and label each cell based on the reference position
    for i in range(1, 10):
        cell_x = bin_x + slot_reference_position[i][0]
        cell_y = bin_y + slot_reference_position[i][1]
        cell_rect = plt.Rectangle((cell_x - 0.06, cell_y - 0.06), 0.12, 0.12, linewidth=1, edgecolor='grey', facecolor='none')
        ax.add_patch(cell_rect)
        
        # Label each cell in bin8 with a number
        if bin_name == 'bin8':
            ax.text(cell_x, cell_y, str(i), ha='center', va='center', fontsize=6)


# Plotting AGVs and their grid cells
for agv_name, pos in agvs.items():
    agv_x, agv_y = pos[0], pos[1]
    rect = plt.Rectangle((agv_x - agv_size[0] / 2, agv_y - agv_size[1] / 2),
                         agv_size[0], agv_size[1], linewidth=2, edgecolor='blue', facecolor='none')
    ax.add_patch(rect)
    
    # Draw and label each cell based on the relative position for AGVs
    for i in range(1, 5):
        cell_x = agv_x + agv_cell_relative_position[i][0]
        cell_y = agv_y + agv_cell_relative_position[i][1]
        cell_rect = plt.Rectangle((cell_x - 0.06, cell_y - 0.06), 0.12, 0.12, linewidth=1, edgecolor='grey', facecolor='none')
        ax.add_patch(cell_rect)
        
        # Label each cell in agv4 with a number
        if agv_name == 'agv4':
            ax.text(cell_x, cell_y, str(i), ha='center', va='center', fontsize=6)



# Plotting tray slots
for slot_name, slot_pos in tray_slots_location.items():
    slot_x, slot_y = slot_pos[0], slot_pos[1]
    # Draw tray slot
    rect = plt.Rectangle((slot_x - agv_size[0] / 2, slot_y - agv_size[1] / 2),
                         agv_size[0], agv_size[1], linewidth=2, edgecolor='green', facecolor='none')
    ax.add_patch(rect)
    # Label tray slot
    ax.text(slot_x, slot_y, slot_name, ha='center', va='center', fontsize=4, color='green')

# Plot robots
ax.plot(ceiling_robot[1], ceiling_robot[0], 'ro', markersize=10, label='Ceiling Robot')
ax.plot(floor_robot[1], floor_robot[0], 'bo', markersize=10, label='Floor Robot')

# Plot settings
ax.set_xlim(-4, 2)
ax.set_ylim(-6.5, 6.5)
ax.set_xlabel('X Position')
ax.set_ylabel('Y Position')
ax.set_title('2D Layout of Bins, AGVs, Tray Slots, and Robots')
ax.legend()
ax.set_aspect('equal')
plt.grid()
plt.show()

# 现在有一组零件
# {"blue":'bin1_2', "green":'bin1_1', "green":'bin3_6',"red":'bin1_3'，"blue":'bin2_2', "green":'bin2_1', "green":'bin4_6',"red":'bin5_3'}
# 现在有三个任务  {floor pick blue on agv3_1, floor pick green on agv3_2, ceiling pick red on agv3_3}
# 为每一个任务确定一个零件（位置名称就行类似，‘bin1_1’,一个零件只能给一个任务），使得总路程最短，需要注意的是，机器人完成一个任务后，他的位置会变成该任务的目标位置
# 我需要使用floor 机器人将一个  "blue" 零件放置到agv3_1 上面， 请给我需要去抓取零件的位置，和总路程，并用一根红线在图上标注总路程
# 我需要使用floor 机器人将一个  "green" 零件放置到agv3_2 上面， 请给我需要去抓取零件的位置，和总路程，并用一根红线在图上标注总路程