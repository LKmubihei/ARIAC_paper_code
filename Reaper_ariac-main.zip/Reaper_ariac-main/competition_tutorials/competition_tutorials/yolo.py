#!/usr/bin/env python3

import os
from pathlib import Path

import torch
from models.common import DetectMultiBackend
from utils.dataloaders import LoadImages
from utils.general import (check_img_size, non_max_suppression, scale_coords, xyxy2xywh)
from utils.plots import colors
from utils.torch_utils import select_device, smart_inference_mode, time_sync
import logging

logging.getLogger().setLevel(logging.ERROR)

part_names = ['pump', 'regulator', 'sensor', 'battery']

class PartDetector:
    def __init__(self, weights, data, imgsz=(640, 640), conf_thres=0.25, iou_thres=0.45, max_det=1000, device='cpu'):
        self.weights = weights
        self.data = data
        self.imgsz = imgsz
        self.conf_thres = conf_thres
        self.iou_thres = iou_thres
        self.max_det = max_det
        self.device = device

        # Load model
        self.device = select_device(device)
        self.model = DetectMultiBackend(weights, device=self.device, data=data)
        self.stride, self.names, self.pt = self.model.stride, self.model.names, self.model.pt
        self.imgsz = check_img_size(imgsz, s=self.stride)  # check image size
        self.model.warmup(imgsz=(1 if self.pt else 1, 3, *self.imgsz))  # warmup

    @smart_inference_mode()
    def detect(self, source):

        source = str(source)
        # Dataloader
        dataset = LoadImages(source, img_size=self.imgsz, stride=self.stride, auto=self.pt)

        detected_parts = {}

        # Run inference
        for path, im, im0s, vid_cap, s in dataset:
            im = torch.from_numpy(im).to(self.device)
            im = im.half() if self.model.fp16 else im.float()  # uint8 to fp16/32
            im /= 255  # 0 - 255 to 0.0 - 1.0
            if len(im.shape) == 3:
                im = im[None]  # expand for batch dim

            # Inference
            pred = self.model(im)

            # NMS
            pred = non_max_suppression(pred, self.conf_thres, self.iou_thres, max_det=self.max_det)

            # Process predictions
            for det in pred:  # per image
                if len(det):
                    # Rescale boxes from img_size to im0 size
                    det[:, :4] = scale_coords(im.shape[2:], det[:, :4], im0s.shape).round()

                    # Write results
                    for *xyxy, conf, cls in reversed(det):
                        detected_parts[Path(path).name] = part_names[int(cls)]

        return detected_parts

    def detect_part_type(self, image_path):
        return self.detect(source=image_path)

if __name__ == "__main__":
    detector = PartDetector(
        weights='/home/lk/ariac_ws/src/Reaper_ariac-main/competition_tutorials/config/best.pt',
        data='/home/lk/ariac_ws/src/Reaper_ariac-main/competition_tutorials/config/data.yaml',
        imgsz=(640, 640),
        conf_thres=0.25,
        iou_thres=0.45,
        max_det=1000,
        device='cpu'
    )
    image_path = '/home/lk/ariac_ws/src/Reaper_ariac-main/photo'
    detected_parts = detector.detect_part_type(image_path)
    print(f'Detected parts: {detected_parts}')
