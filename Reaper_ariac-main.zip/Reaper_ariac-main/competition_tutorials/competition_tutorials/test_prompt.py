from math import sqrt
from typing import List, Dict, Tuple,Literal
from typing import Annotated, Sequence, TypedDict

from langchain_openai import ChatOpenAI
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages

from langchain_core.messages import HumanMessage,FunctionMessage,BaseMessage,HumanMessage,ToolMessage,AIMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph, MessagesState,START
from langgraph.prebuilt import ToolNode,tools_condition
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_experimental.utilities import PythonREPL
from langchain_community.tools.tavily_search import TavilySearchResults
import operator
from langchain_core.pydantic_v1 import BaseModel,Field

from openai import OpenAI

client = OpenAI(
    # 将这里换成你在便携AI聚合API后台生成的令牌
    api_key="sk-9paT6U0MXlwCr8N63f1123E1E8564776A4Da9d4011Ad8cA7",
    # 这里将官方的接口访问地址替换成便携AI聚合API的入口地址
    base_url="https://api.bianxie.ai/v1"
)


import os
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = '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'
os.environ["TAVILY_API_KEY"] = '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'
os.environ["LANGCHAIN_PROJECT"] = "Multi-agent Collaboration"
llm = ChatOpenAI(model="gpt-4o-mini", api_key="sk-9paT6U0MXlwCr8N63f1123E1E8564776A4Da9d4011Ad8cA7",base_url="https://api.bianxie.ai/v1",temperature=0)

# 定义机器人状态
class RobotInfo(TypedDict):
    is_enabled: bool
    is_idle: bool

# 定义任务分配的状态
class TaskAllocationState(TypedDict):
    task_descriptions: List[str]
    part_descriptions: List[str]
    floor_robot_info: RobotInfo
    ceiling_robot_info: RobotInfo
    floor_robot_tasks: List[str]
    ceiling_robot_tasks: List[str]

# 初始化任务和零件描述
task_descriptions = [
    'kitting blue battery on agv4',
    'kitting purple pump on agv4',
    'assembly purple pump on as2'
]

part_descriptions = [
    'purple pump on bin2',
    'blue battery on bin6'
]

# 初始化机器人状态
floor_robot_info = {'is_enabled': True, 'is_idle': True}
ceiling_robot_info = {'is_enabled': True, 'is_idle': True}

# 定义用于与 LLM 交互的函数
def llm_task_allocator(state: TaskAllocationState):
    prompt = f"""
你是一名机器人系统的专家，负责为地面机器人和天花板机器人分配任务，以最小化总完成时间。

规则：
- 地面机器人只能执行 kitting 任务。
- 天花板机器人一次只能处理一个任务，优先级如下：Combined > Assembly > Kitting。
- 如果零件需要翻转（'flip'），则拾取它将花费更多时间。
- 根据提供的任务和零件，分配任务给机器人，以最小化总完成时间。

机器人状态：
- 地面机器人：{'可用' if state['floor_robot_info']['is_enabled'] else '不可用'}，{'空闲' if state['floor_robot_info']['is_idle'] else '忙碌'}
- 天花板机器人：{'可用' if state['ceiling_robot_info']['is_enabled'] else '不可用'}，{'空闲' if state['ceiling_robot_info']['is_idle'] else '忙碌'}

环境中可用的零件：
{chr(10).join(state['part_descriptions'])}

可用的任务：
{chr(10).join(state['task_descriptions'])}

请根据上述规则，将任务分配给机器人，并以以下格式输出：
Floor robot tasks: [任务1, 任务2]
Ceiling robot tasks: [任务1]
"""

    # 调用 Chat Completion API
    response = client.chat.completions.create(
        model='gpt-4o-mini',
        messages=[
            {'role': 'user', 'content': prompt}
        ],
        max_tokens=500,
        temperature=0,
        n=1,
        stop=None
    )

    # 处理响应
    allocation_text = response.choices[0].message['content'].strip()
    print("LLM 分配结果：")
    print(allocation_text)

    # 解析分配结果
    floor_tasks = []
    ceiling_tasks = []

    import re

    floor_match = re.search(r'Floor robot tasks:\s*\[(.*?)\]', allocation_text, re.DOTALL)
    ceiling_match = re.search(r'Ceiling robot tasks:\s*\[(.*?)\]', allocation_text, re.DOTALL)

    if floor_match:
        floor_tasks_str = floor_match.group(1)
        floor_tasks = [task.strip() for task in floor_tasks_str.split(',') if task.strip()]
    if ceiling_match:
        ceiling_tasks_str = ceiling_match.group(1)
        ceiling_tasks = [task.strip() for task in ceiling_tasks_str.split(',') if task.strip()]

    return {
        'floor_robot_tasks': floor_tasks,
        'ceiling_robot_tasks': ceiling_tasks
    }

# 使用 langgraph 构建任务分配流程
def allocate_tasks(state: TaskAllocationState):
    allocation_result = llm_task_allocator(state)
    state['floor_robot_tasks'] = allocation_result['floor_robot_tasks']
    state['ceiling_robot_tasks'] = allocation_result['ceiling_robot_tasks']
    return state

# 定义任务执行函数（这里简单打印）
def execute_tasks(state: TaskAllocationState):
    if state['floor_robot_tasks']:
        print("地面机器人将执行以下任务：")
        for task in state['floor_robot_tasks']:
            print(f"- {task}")
    else:
        print("地面机器人没有被分配任务。")

    if state['ceiling_robot_tasks']:
        print("天花板机器人将执行以下任务：")
        for task in state['ceiling_robot_tasks']:
            print(f"- {task}")
    else:
        print("天花板机器人没有被分配任务。")

    return state

# 构建 langgraph 图
graph = StateGraph(TaskAllocationState)
graph.add_node("allocate", allocate_tasks)
graph.add_node("execute", execute_tasks)
graph.add_edge(START, "allocate")
graph.add_edge("allocate", "execute")
graph.add_edge("execute", END)

# 初始化状态
initial_state = {
    'task_descriptions': task_descriptions,
    'part_descriptions': part_descriptions,
    'floor_robot_info': floor_robot_info,
    'ceiling_robot_info': ceiling_robot_info,
    'floor_robot_tasks': [],
    'ceiling_robot_tasks': []
}

# 运行图
app = graph.compile()
final_state = app.stream(initial_state)
print(final_state)
# from IPython.display import Image, display

# display(Image(app.get_graph(xray=True).draw_mermaid_png()))

# from openai import OpenAI

# client = OpenAI(
#     # 将这里换成你在便携AI聚合API后台生成的令牌
#     api_key="sk-9paT6U0MXlwCr8N63f1123E1E8564776A4Da9d4011Ad8cA7",
#     # 这里将官方的接口访问地址替换成便携AI聚合API的入口地址
#     base_url="https://api.bianxie.ai/v1"
# )

# # 定义环境中的零件和任务
# part_descriptions = ['purple pump on bin2', 'blue battery on bin6']
# task_descriptions = [
#     'kitting blue battery on agv4',
#     'kitting purple pump on agv2',
#     'assembly purple pump on as2'
# ]

# def allocate_tasks_with_llm():
#         # Prepare the prompt for the LLM
#     prompt = """
#     You are an expert task allocator for a robotic system. Your job is to assign tasks to two robots (Floor robot and Ceiling robot) to minimize the total completion time.

#     Rules:
#     - Floor robot can only handle kitting tasks.
#     - Ceiling robot can handle one task at a time with the following priority: Combined > Assembly > Kitting.
#     - If a part needs flipping ('flip'), it will take more time to pick up.
#     - Based on the provided tasks and parts, assign tasks to robots to minimize total completion time.

#     Available parts in the environment:
#     {}
#     Available tasks:
#     {}

#     Assign tasks to robots following the rules, and output the assignment in the following format:
#     Floor robot tasks: [task1, task2, ...]
#     Ceiling robot tasks: [task1, task2, ...]

# """.format('\n'.join(part_descriptions), '\n'.join(task_descriptions))

#     # Call the LLM to get the task allocation
#     response = client.chat.completions.create(
#         model='gpt-4o-mini',
#         messages=[
#             {'role': 'user', 'content': prompt}
#         ],
#         max_tokens=500,
#         temperature=0,
#         n=1,
#         stop=None
#     )

#     # Process the response
#     print(response.choices[0].message.content)
#     allocation = response.choices[0].message.content.strip()



# allocate_tasks_with_llm()


