from math import sqrt
from typing import List, Dict, Tuple,Literal
from typing import Annotated, Sequence, TypedDict

from langchain_openai import ChatOpenAI
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages

from langchain_core.messages import HumanMessage,FunctionMessage,BaseMessage,HumanMessage,ToolMessage,AIMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph, MessagesState,START
from langgraph.prebuilt import ToolNode,tools_condition
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder,PromptTemplate
from langchain_experimental.utilities import PythonREPL
from langchain_community.tools.tavily_search import TavilySearchResults
import operator
from pydantic import BaseModel, Field
from langchain_core.output_parsers import JsonOutputParser
from competition_tutorials.data import bin_slot_positions, agv_slot_positions

import os
os.environ["LANGCHAIN_TRACING_V2"] = "true"
os.environ["LANGCHAIN_API_KEY"] = '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'
os.environ["TAVILY_API_KEY"] = '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'
os.environ["LANGCHAIN_PROJECT"] = "Multi-agent Collaboration"
llm = ChatOpenAI(model="gpt-4o-mini", api_key="sk-9paT6U0MXlwCr8N63f1123E1E8564776A4Da9d4011Ad8cA7",base_url="https://api.bianxie.ai/v1",temperature=0)


# 定义任务分配的状态
class TaskAllocationState(BaseModel):
    floor_tasks: List[str]="Tasks assigned to the floor robot"
    ceiling_tasks: List[str]="Tasks assigned to the ceiling robot"
parser = JsonOutputParser(pydantic_object=TaskAllocationState)

import itertools
import numpy as np
import re

def calculate_distance(pos1, pos2):
    """计算两点之间的欧几里得距离"""
    return np.linalg.norm(np.array(pos1) - np.array(pos2))

def extract_part_position(part_description, bin_slot_positions):
    """从零件描述中提取零件位置"""
    # 正则表达式匹配槽位名称
    match = re.search(r'place on (\w+)', part_description)
    if match:
        slot_name = match.group(1)
        return bin_slot_positions.get(slot_name)
    return None

def extract_agv_position(task, agv_slot_positions):
    """从任务描述中提取目标AGV位置"""
    match = re.search(r'on (\w+)', task)
    if match:
        agv_name = match.group(1)
        return agv_slot_positions.get(agv_name)
    return None

def assign_parts_and_calculate_route(tasks, parts, robot_positions):
    """
    为每个任务分配零件，并计算总路程
    :param tasks: 任务字典
    :param parts: 零件描述
    :param robot_positions: 机器人的初始位置
    :param bin_slot_positions: 槽位位置
    :param agv_slot_positions: AGV槽位位置
    :return: 最优分配的零件和最短总路程
    """
    best_route = float('inf')
    best_assignment = {}

    # 为任务和零件创建所有可能的组合
    for assignment in itertools.permutations(parts, sum(len(task) for task in tasks.values())):
        current_route = 0
        current_positions = {'floor':robot_positions['floor']['position'],'ceiling':robot_positions['ceiling']['position']}

        assignment_list = list(assignment)
        current_assignment = {key: [] for key in tasks.keys()}

        # 对于每种机器人类型和其任务
        for robot_type, task_list in tasks.items():
            for task in task_list:
                # 提取当前任务对应的零件
                part = assignment_list.pop(0)

                # 提取零件位置和目标AGV位置
                part_position = extract_part_position(part, bin_slot_positions)
                target_agv_position = extract_agv_position(task, agv_slot_positions)

                if part_position is None or target_agv_position is None:
                    continue  # 跳过无效的分配

                # 计算从机器人当前位置到零件位置的距离
                if robot_type == 'floor':
                    distance_to_part = calculate_distance(current_positions['floor'], part_position)
                    # 更新机器人的位置为目标AGV
                    current_positions['floor'] = target_agv_position
                else:
                    distance_to_part = calculate_distance(current_positions['ceiling'], part_position)
                    # 更新机器人的位置为目标AGV
                    current_positions['ceiling'] = target_agv_position

                # 计算从零件位置到目标AGV的距离
                distance_to_agv = calculate_distance(part_position, target_agv_position)

                # 更新当前路径
                current_route += distance_to_part + distance_to_agv

                # 记录分配结果
                current_assignment[robot_type].append({task: part})

        # 更新最优分配和最短路径
        if current_route < best_route:
            best_route = current_route
            best_assignment = current_assignment

    return best_assignment, best_route

def llm_output(part_descriptions,task_descriptions,robot_descriptions):
    template = """
    You are an expert task allocator for a robotic system. Your goal is to assign tasks to two robots (Floor robot and Ceiling robot) and then prioritize the tasks for each robot in order to minimize the total completion time. Follow the rules below:

    Task types:
    Combined and Assembly tasks can only be assigned to the Ceiling robot.
    Kitting tasks can be assigned to either the Floor robot or the Ceiling robot.
    Task timing:
    Both robots take the same amount of time to complete a task.
    However, parts that require flipping ('flip') will take extra time, so prioritize parts that do not require flipping.
    Task queue prioritization:
    The Ceiling robot can only process one task at a time, and its task queue should be prioritized in the following order: Combined > Assembly > Kitting.
    Task and part descriptions:
    The total number of tasks matches the number of task descriptions.
    The total number of parts matches the number of part descriptions.

    \n{format_instructions}\n
    To minimize total completion time, assign some kitting tasks to the Ceiling robot after its higher-priority tasks are assigned.    
    Assign tasks to robots following the rules, and output the assignment in the following format (Output only the final task assignment in the following format):
        Floor robot tasks: [task1, task2, ...]
        Ceiling robot tasks: [task1, task2, ...]

    Here is an example setup:
    Task descriptions:
    [
    'kitting blue battery on agv4_1',
    'kitting blue battery on agv4_2',
    'kitting purple pump on agv4_3',
    'kitting purple pump on agv4_4',
    'assembly purple pump on as2'
    ]
    Part descriptions:
    [  'purple pump on bin2',  'blue battery on bin6']

    Expected output:
    floor_tasks: ['kitting blue battery on agv4_1', 'kitting blue battery on agv4_2', 'kitting purple pump on agv4_3']
    ceiling_tasks: ['assembly purple pump on as2', 'kitting purple pump on agv4_4']

    Now, Available parts in the environment:
        {part_descriptions}
        Available tasks:
        {task_descriptions}
        Available robots:
        {robot_descriptions}

    """

    prompt = PromptTemplate(
        template=template,
        input_variables=["part_descriptions", "task_descriptions"],
        partial_variables={"format_instructions": parser.get_format_instructions()},
    )

    chain = prompt | llm | parser
    task_assignment = chain.invoke({"part_descriptions": part_descriptions, "task_descriptions":task_descriptions, "robot_descriptions":robot_descriptions})
    print("大模型规划的结果：",task_assignment)
    result,_ = assign_parts_and_calculate_route(task_assignment,part_descriptions,robot_descriptions)
    return result