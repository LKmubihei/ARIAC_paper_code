import numpy as np

def calculate_delta(angle_radians):
    start_point = (-6.44, -3.0)   # 以as3为例子
    origin = (-7.7, -3.0)
    
    translated_x = start_point[0] - origin[0]
    translated_y = start_point[1] - origin[1]
    
    # Apply rotation
    rotated_x = translated_x * np.cos(angle_radians) - translated_y * np.sin(angle_radians)
    rotated_y = translated_x * np.sin(angle_radians) + translated_y * np.cos(angle_radians)
    
    # Translate back
    new_x = rotated_x + origin[0]
    new_y = rotated_y + origin[1]
    
    # Calculate delta
    delta_x = new_x - start_point[0]
    delta_y = new_y - start_point[1]
    
    return delta_x, delta_y


# Example usage
start_point = (-6.44, -3.0)
origin = (-7.7, -3.0)
angle_degrees = 0 # Example angle

delta_x, delta_y = calculate_delta(angle_degrees)
print(f"Delta X: {delta_x}, Delta Y: {delta_y}")
